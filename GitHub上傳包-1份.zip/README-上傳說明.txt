把r資料夾完整上傳至STEM專案根目錄，與index.html並列。不要刪除原有r資料夾內的舊作品。待GitHub Pages更新後，回到老師收集台核對連結再打印。
作品網址：
https://lccch0614.github.io/STEM/r/w-2cbfe3e99d044ba9ad59d193.html